package pepse.util;

public class ColorSupplier {
}
