package pepse.util;

public class NoiseGenerator {
}
